using System;
using HMIHost.Utils;

namespace HMIHost
{
    /// <summary>
    /// 应用程序全局辅助类
    /// </summary>
    public static class Global
    {
        /// <summary>
        /// 初始化全局异常处理（在 App 构造函数中调用）
        /// </summary>
        public static void InitializeGlobalExceptionHandling()
        {
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
            {
                Logger.Fatal($"未处理的域异常: {e.ExceptionObject}");
                Logger.CloseAndFlush();
            };

            System.Windows.Application.Current.DispatcherUnhandledException += (s, e) =>
            {
                Logger.Fatal($"UI 线程异常: {e.Exception}");
                e.Handled = true;
            };
        }
    }
}
