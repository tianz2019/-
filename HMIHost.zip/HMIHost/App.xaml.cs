using System.Windows;

namespace HMIHost
{
    public partial class App : Application
    {
        protected override void OnExit(ExitEventArgs e)
        {
            Utils.Logger.CloseAndFlush();
            base.OnExit(e);
        }
    }
}
