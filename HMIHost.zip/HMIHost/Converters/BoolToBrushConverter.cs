using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace HMIHost.Converters
{
    /// <summary>
    /// 布尔值转画刷转换器（用于通道列表连接状态背景色）
    /// </summary>
    public class BoolToBrushConverter : IValueConverter
    {
        private static readonly SolidColorBrush ConnectedBrush = new SolidColorBrush(Color.FromRgb(0xE8, 0xF5, 0xE9)); // 浅绿
        private static readonly SolidColorBrush DisconnectedBrush = new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF)); // 白色

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool b && b)
                return ConnectedBrush;
            return DisconnectedBrush;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
