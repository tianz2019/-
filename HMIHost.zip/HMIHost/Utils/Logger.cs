using System;
using System.IO;
using Serilog;

namespace HMIHost.Utils
{
    /// <summary>
    /// 全局日志工具类
    /// </summary>
    public static class Logger
    {
        private static readonly Serilog.Core.Logger _logger;
        private static readonly object _lockObj = new object();

        static Logger()
        {
            // 确保日志目录存在
            var logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            Directory.CreateDirectory(logDir);

            _logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.Console(outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
                .WriteTo.File(
                    path: Path.Combine(logDir, "hmi-.log"),
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 30,
                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}",
                    shared: true)
                .CreateLogger();

            Information("═══════════════════════════════════════════════════════════════");
            Information("  HMI Host Application Framework 启动");
            Information("  时间: {0}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            Information("═══════════════════════════════════════════════════════════════");
        }

        public static void Debug(string message, params object[] args)
        {
            lock (_lockObj) _logger.Debug(message, args);
        }

        public static void Information(string message, params object[] args)
        {
            lock (_lockObj) _logger.Information(message, args);
        }

        public static void Warning(string message, params object[] args)
        {
            lock (_lockObj) _logger.Warning(message, args);
        }

        public static void Error(string message, params object[] args)
        {
            lock (_lockObj) _logger.Error(message, args);
        }

        public static void Error(Exception ex, string message = "")
        {
            lock (_lockObj) _logger.Error(ex, message);
        }

        public static void Fatal(string message, params object[] args)
        {
            lock (_lockObj) _logger.Fatal(message, args);
        }

        /// <summary>关闭并刷新日志</summary>
        public static void CloseAndFlush()
        {
            _logger?.Dispose();
        }
    }
}
