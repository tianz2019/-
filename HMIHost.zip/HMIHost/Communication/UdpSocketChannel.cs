using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using HMIHost.Utils;

namespace HMIHost.Communication
{
    /// <summary>
    /// UDP Socket 通信通道
    /// </summary>
    public class UdpSocketChannel : ICommunicationChannel
    {
        private readonly int _localPort;
        private readonly string _remoteIp;
        private readonly int _remotePort;
        private readonly int _bufferSize;

        private UdpClient _udpClient;
        private readonly object _lockObj = new object();
        private CancellationTokenSource _cts;
        private Task _receiveTask;
        private volatile bool _isRunning;
        private volatile bool _isConnected;
        private IPEndPoint _remoteEndPoint;

        public string Name { get; }
        public bool IsConnected => _isConnected;

        public event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;
        public event EventHandler<DataReceivedEventArgs> DataReceived;
        public event EventHandler<CommunicationErrorEventArgs> ErrorOccurred;

        public UdpSocketChannel(int localPort = 9001, string remoteIp = "127.0.0.1", int remotePort = 9001, int bufferSize = 4096)
        {
            _localPort = localPort;
            _remoteIp = remoteIp;
            _remotePort = remotePort;
            _bufferSize = bufferSize;
            Name = $"UDP:{remoteIp}:{remotePort}";
        }

        public void Open()
        {
            try
            {
                _udpClient = new UdpClient(_localPort);
                _remoteEndPoint = new IPEndPoint(IPAddress.Parse(_remoteIp), _remotePort);
                _isConnected = true;
                _isRunning = true;

                Logger.Information($"[{Name}] UDP 已启动，监听本地端口 {_localPort}");
                ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(true, "UDP 已启动"));

                _cts = new CancellationTokenSource();
                _receiveTask = Task.Run(() => ReceiveLoop(_cts.Token));
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 启动 UDP 失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "启动 UDP 失败", ex));
                ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, ex.Message));
            }
        }

        private async Task ReceiveLoop(CancellationToken token)
        {
            var remoteEp = new IPEndPoint(IPAddress.Any, 0);
            try
            {
                while (!token.IsCancellationRequested && _isRunning)
                {
                    var result = await _udpClient.ReceiveAsync(token);
                    var data = result.Buffer;
                    var sender = result.RemoteEndPoint;

                    Logger.Debug($"[{Name}] 接收[{data.Length}字节] 来自 {sender}: {BitConverter.ToString(data)}");
                    DataReceived?.Invoke(this, new DataReceivedEventArgs(data, Name));
                }
            }
            catch (OperationCanceledException) { }
            catch (ObjectDisposedException) { }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] UDP 接收异常: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "UDP 接收异常", ex));
            }
        }

        public void Close()
        {
            _isRunning = false;
            _isConnected = false;
            try
            {
                _cts?.Cancel();
                _udpClient?.Close();
                Logger.Information($"[{Name}] UDP 已停止");
                ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, "UDP 已停止"));
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 关闭 UDP 失败: {ex.Message}");
            }
        }

        public bool Send(byte[] data)
        {
            try
            {
                lock (_lockObj)
                {
                    if (!_isConnected || _udpClient == null) return false;
                    _udpClient.Send(data, data.Length, _remoteEndPoint);
                    Logger.Debug($"[{Name}] 发送[{data.Length}字节] 到 {_remoteEndPoint}: {BitConverter.ToString(data)}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 发送失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "发送失败", ex));
                return false;
            }
        }

        public bool Send(string text)
        {
            var data = Encoding.UTF8.GetBytes(text);
            return Send(data);
        }

        public void Dispose()
        {
            Close();
            _udpClient?.Dispose();
        }
    }
}
