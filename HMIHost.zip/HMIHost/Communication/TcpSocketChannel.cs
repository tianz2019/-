using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using HMIHost.Utils;

namespace HMIHost.Communication
{
    /// <summary>
    /// TCP Socket 通信通道（客户端模式）
    /// </summary>
    public class TcpSocketChannel : ICommunicationChannel
    {
        private readonly string _ipAddress;
        private readonly int _port;
        private readonly int _bufferSize;
        private readonly int _reconnectInterval;

        private TcpClient _tcpClient;
        private NetworkStream _stream;
        private readonly object _lockObj = new object();
        private CancellationTokenSource _cts;
        private Task _receiveTask;
        private volatile bool _isRunning;
        private volatile bool _isConnected;

        public string Name { get; }
        public bool IsConnected => _isConnected;

        public event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;
        public event EventHandler<DataReceivedEventArgs> DataReceived;
        public event EventHandler<CommunicationErrorEventArgs> ErrorOccurred;

        public TcpSocketChannel(string ipAddress = "127.0.0.1", int port = 9000, int bufferSize = 4096, int reconnectInterval = 5000)
        {
            _ipAddress = ipAddress;
            _port = port;
            _bufferSize = bufferSize;
            _reconnectInterval = reconnectInterval;
            Name = $"TCP:{ipAddress}:{port}";
        }

        public void Open()
        {
            _isRunning = true;
            Task.Run(() => ConnectWithRetry());
        }

        private async Task ConnectWithRetry()
        {
            while (_isRunning)
            {
                try
                {
                    _tcpClient = new TcpClient();
                    await _tcpClient.ConnectAsync(_ipAddress, _port);
                    _stream = _tcpClient.GetStream();
                    _isConnected = true;

                    Logger.Information($"[{Name}] TCP 已连接");
                    ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(true, "TCP 已连接"));

                    _cts = new CancellationTokenSource();
                    _receiveTask = Task.Run(() => ReceiveLoop(_cts.Token));

                    // 等待接收任务结束（连接断开）
                    await _receiveTask;
                }
                catch (Exception ex)
                {
                    _isConnected = false;
                    Logger.Error($"[{Name}] TCP 连接失败: {ex.Message}");
                    ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "TCP 连接失败", ex));
                    ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, ex.Message));
                }

                if (!_isRunning) break;

                Logger.Information($"[{Name}] {_reconnectInterval}ms 后尝试重连...");
                await Task.Delay(_reconnectInterval);
            }
        }

        private async Task ReceiveLoop(CancellationToken token)
        {
            var buffer = new byte[_bufferSize];
            try
            {
                while (!token.IsCancellationRequested && _isConnected)
                {
                    int bytesRead = await _stream.ReadAsync(buffer, 0, buffer.Length, token);
                    if (bytesRead == 0)
                    {
                        // 连接被对端关闭
                        _isConnected = false;
                        Logger.Warning($"[{Name}] TCP 连接被对端关闭");
                        ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, "连接被对端关闭"));
                        break;
                    }

                    var data = new byte[bytesRead];
                    Array.Copy(buffer, data, bytesRead);
                    Logger.Debug($"[{Name}] 接收[{bytesRead}字节]: {BitConverter.ToString(data)}");
                    DataReceived?.Invoke(this, new DataReceivedEventArgs(data, Name));
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                _isConnected = false;
                Logger.Error($"[{Name}] TCP 接收异常: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "TCP 接收异常", ex));
                ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, ex.Message));
            }
        }

        public void Close()
        {
            _isRunning = false;
            _isConnected = false;
            try
            {
                _cts?.Cancel();
                _stream?.Close();
                _tcpClient?.Close();
                Logger.Information($"[{Name}] TCP 已断开");
                ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, "TCP 已断开"));
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 关闭 TCP 失败: {ex.Message}");
            }
        }

        public bool Send(byte[] data)
        {
            try
            {
                lock (_lockObj)
                {
                    if (!_isConnected || _stream == null) return false;
                    _stream.Write(data, 0, data.Length);
                    _stream.Flush();
                    Logger.Debug($"[{Name}] 发送[{data.Length}字节]: {BitConverter.ToString(data)}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                _isConnected = false;
                Logger.Error($"[{Name}] 发送失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "发送失败", ex));
                return false;
            }
        }

        public bool Send(string text)
        {
            var data = Encoding.UTF8.GetBytes(text);
            return Send(data);
        }

        public void Dispose()
        {
            Close();
            _tcpClient?.Dispose();
        }
    }
}
