using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using HMIHost.Utils;

namespace HMIHost.Communication
{
    /// <summary>
    /// Modbus TCP 通信通道
    /// </summary>
    public class ModbusTcpChannel : ICommunicationChannel
    {
        private readonly string _ipAddress;
        private readonly int _port;
        private readonly byte _slaveId;
        private readonly int _timeout;
        private readonly int _retryCount;

        private TcpClient _tcpClient;
        private NetworkStream _stream;
        private readonly object _lockObj = new object();
        private ushort _transactionId = 0;
        private CancellationTokenSource _cts;
        private Task _receiveTask;

        public string Name { get; }
        public bool IsConnected => _tcpClient?.Connected ?? false;

        public event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;
        public event EventHandler<DataReceivedEventArgs> DataReceived;
        public event EventHandler<CommunicationErrorEventArgs> ErrorOccurred;

        public ModbusTcpChannel(string ipAddress = "127.0.0.1", int port = 502, byte slaveId = 1, int timeout = 5000, int retryCount = 3)
        {
            _ipAddress = ipAddress;
            _port = port;
            _slaveId = slaveId;
            _timeout = timeout;
            _retryCount = retryCount;
            Name = $"ModbusTCP:{ipAddress}:{port}";
        }

        public void Open()
        {
            try
            {
                lock (_lockObj)
                {
                    _tcpClient = new TcpClient();
                    _tcpClient.ReceiveTimeout = _timeout;
                    _tcpClient.SendTimeout = _timeout;
                    _tcpClient.Connect(_ipAddress, _port);
                    _stream = _tcpClient.GetStream();

                    Logger.Information($"[{Name}] Modbus TCP 已连接");
                    ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(true, "Modbus TCP 已连接"));

                    // 启动接收循环
                    _cts = new CancellationTokenSource();
                    _receiveTask = Task.Run(() => ReceiveLoop(_cts.Token));
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 连接 Modbus TCP 失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "连接 Modbus TCP 失败", ex));
                ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, ex.Message));
            }
        }

        public void Close()
        {
            try
            {
                _cts?.Cancel();
                lock (_lockObj)
                {
                    _stream?.Close();
                    _tcpClient?.Close();
                    Logger.Information($"[{Name}] Modbus TCP 已断开");
                    ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, "Modbus TCP 已断开"));
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 关闭 Modbus TCP 失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "关闭 Modbus TCP 失败", ex));
            }
        }

        /// <summary>
        /// 读取保持寄存器 (Function Code 0x03)
        /// </summary>
        /// <param name="startAddress">起始地址 (0-based)</param>
        /// <param name="quantity">寄存器数量</param>
        /// <returns>寄存器值数组</returns>
        public ushort[] ReadHoldingRegisters(ushort startAddress, ushort quantity)
        {
            var request = BuildReadRequest(0x03, startAddress, quantity);
            var response = SendAndReceiveModbus(request);
            if (response == null || response.Length < 9) return null;

            int byteCount = response[8];
            var values = new ushort[byteCount / 2];
            for (int i = 0; i < values.Length; i++)
            {
                values[i] = (ushort)((response[9 + i * 2] << 8) | response[10 + i * 2]);
            }
            return values;
        }

        /// <summary>
        /// 读取输入寄存器 (Function Code 0x04)
        /// </summary>
        public ushort[] ReadInputRegisters(ushort startAddress, ushort quantity)
        {
            var request = BuildReadRequest(0x04, startAddress, quantity);
            var response = SendAndReceiveModbus(request);
            if (response == null || response.Length < 9) return null;

            int byteCount = response[8];
            var values = new ushort[byteCount / 2];
            for (int i = 0; i < values.Length; i++)
            {
                values[i] = (ushort)((response[9 + i * 2] << 8) | response[10 + i * 2]);
            }
            return values;
        }

        /// <summary>
        /// 读取线圈状态 (Function Code 0x01)
        /// </summary>
        public bool[] ReadCoils(ushort startAddress, ushort quantity)
        {
            var request = BuildReadRequest(0x01, startAddress, quantity);
            var response = SendAndReceiveModbus(request);
            if (response == null || response.Length < 9) return null;

            int byteCount = response[8];
            var values = new bool[quantity];
            for (int i = 0; i < quantity; i++)
            {
                int byteIndex = 9 + (i / 8);
                int bitIndex = i % 8;
                values[i] = (response[byteIndex] & (1 << bitIndex)) != 0;
            }
            return values;
        }

        /// <summary>
        /// 写单个线圈 (Function Code 0x05)
        /// </summary>
        public bool WriteSingleCoil(ushort address, bool value)
        {
            ushort data = value ? (ushort)0xFF00 : (ushort)0x0000;
            var request = BuildModbusFrame(_slaveId, 0x05, address, data);
            var response = SendAndReceiveModbus(request);
            return response != null && response.Length >= 12;
        }

        /// <summary>
        /// 写单个寄存器 (Function Code 0x06)
        /// </summary>
        public bool WriteSingleRegister(ushort address, ushort value)
        {
            var request = BuildModbusFrame(_slaveId, 0x06, address, value);
            var response = SendAndReceiveModbus(request);
            return response != null && response.Length >= 12;
        }

        /// <summary>
        /// 写多个寄存器 (Function Code 0x10)
        /// </summary>
        public bool WriteMultipleRegisters(ushort startAddress, ushort[] values)
        {
            _transactionId++;
            var tid = (ushort)_transactionId;
            byte byteCount = (byte)(values.Length * 2);

            // MBAP Header (7) + FunctionCode(1) + Addr(2) + Quantity(2) + ByteCount(1) + Data(N)
            int pduLen = 1 + 2 + 2 + 1 + byteCount;
            var frame = new byte[7 + pduLen];
            // Transaction ID
            frame[0] = (byte)(tid >> 8);
            frame[1] = (byte)(tid & 0xFF);
            // Protocol ID = 0
            frame[2] = 0; frame[3] = 0;
            // Length
            frame[4] = (byte)(pduLen >> 8);
            frame[5] = (byte)(pduLen & 0xFF);
            // Unit ID
            frame[6] = _slaveId;
            // Function Code
            frame[7] = 0x10;
            // Start Address
            frame[8] = (byte)(startAddress >> 8);
            frame[9] = (byte)(startAddress & 0xFF);
            // Quantity
            frame[10] = (byte)(values.Length >> 8);
            frame[11] = (byte)(values.Length & 0xFF);
            // Byte Count
            frame[12] = byteCount;
            // Data
            for (int i = 0; i < values.Length; i++)
            {
                frame[13 + i * 2] = (byte)(values[i] >> 8);
                frame[14 + i * 2] = (byte)(values[i] & 0xFF);
            }

            var response = SendAndReceiveModbus(frame);
            return response != null && response.Length >= 12;
        }

        private byte[] BuildReadRequest(byte functionCode, ushort startAddress, ushort quantity)
        {
            _transactionId++;
            var tid = (ushort)_transactionId;
            byte pduLen = 5; // FC(1) + Addr(2) + Qty(2)
            var frame = new byte[7 + pduLen];
            frame[0] = (byte)(tid >> 8);
            frame[1] = (byte)(tid & 0xFF);
            frame[2] = 0; frame[3] = 0;
            frame[4] = 0; frame[5] = pduLen;
            frame[6] = _slaveId;
            frame[7] = functionCode;
            frame[8] = (byte)(startAddress >> 8);
            frame[9] = (byte)(startAddress & 0xFF);
            frame[10] = (byte)(quantity >> 8);
            frame[11] = (byte)(quantity & 0xFF);
            return frame;
        }

        private byte[] BuildModbusFrame(byte slaveId, byte functionCode, ushort address, ushort data)
        {
            _transactionId++;
            var tid = (ushort)_transactionId;
            byte pduLen = 5;
            var frame = new byte[7 + pduLen];
            frame[0] = (byte)(tid >> 8);
            frame[1] = (byte)(tid & 0xFF);
            frame[2] = 0; frame[3] = 0;
            frame[4] = 0; frame[5] = pduLen;
            frame[6] = slaveId;
            frame[7] = functionCode;
            frame[8] = (byte)(address >> 8);
            frame[9] = (byte)(address & 0xFF);
            frame[10] = (byte)(data >> 8);
            frame[11] = (byte)(data & 0xFF);
            return frame;
        }

        private byte[] SendAndReceiveModbus(byte[] request)
        {
            for (int attempt = 0; attempt < _retryCount; attempt++)
            {
                try
                {
                    lock (_lockObj)
                    {
                        if (!IsConnected || _stream == null)
                        {
                            Logger.Warning($"[{Name}] Modbus TCP 未连接");
                            return null;
                        }

                        // 发送
                        _stream.Write(request, 0, request.Length);
                        _stream.Flush();
                        Logger.Debug($"[{Name}] Modbus 发送: {BitConverter.ToString(request)}");

                        // 接收响应头 (MBAP: 7字节)
                        var header = new byte[7];
                        int read = ReadExact(_stream, header, 0, 7);
                        if (read < 7) return null;

                        // 解析长度
                        int length = (header[4] << 8) | header[5];
                        if (length < 2 || length > 253) return null;

                        // 接收剩余数据
                        var body = new byte[length - 1]; // 去掉 Unit ID
                        read = ReadExact(_stream, body, 0, length - 1);
                        if (read < length - 1) return null;

                        var response = new byte[7 + length - 1];
                        Array.Copy(header, response, 7);
                        Array.Copy(body, 0, response, 7, length - 1);

                        // 检查异常响应
                        if (response[7] >= 0x80)
                        {
                            byte exceptionCode = response[8];
                            Logger.Error($"[{Name}] Modbus 异常响应: Code=0x{exceptionCode:X2}");
                            return null;
                        }

                        return response;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"[{Name}] Modbus 通信失败(第{attempt + 1}次): {ex.Message}");
                    if (attempt == _retryCount - 1)
                    {
                        ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "Modbus 通信失败", ex));
                        return null;
                    }
                    Thread.Sleep(100);
                }
            }
            return null;
        }

        private int ReadExact(NetworkStream stream, byte[] buffer, int offset, int count)
        {
            int totalRead = 0;
            while (totalRead < count)
            {
                int read = stream.Read(buffer, offset + totalRead, count - totalRead);
                if (read == 0) break;
                totalRead += read;
            }
            return totalRead;
        }

        private async Task ReceiveLoop(CancellationToken token)
        {
            // Modbus TCP 是请求-响应模式，数据通过 SendAndReceiveModbus 处理
            // 此循环用于检测连接断开
            try
            {
                while (!token.IsCancellationRequested && IsConnected)
                {
                    await Task.Delay(1000, token);
                }
            }
            catch (OperationCanceledException) { }
        }

        public bool Send(byte[] data)
        {
            try
            {
                lock (_lockObj)
                {
                    if (!IsConnected || _stream == null) return false;
                    _stream.Write(data, 0, data.Length);
                    _stream.Flush();
                    Logger.Debug($"[{Name}] 发送[{data.Length}字节]: {BitConverter.ToString(data)}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 发送失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "发送失败", ex));
                return false;
            }
        }

        public bool Send(string text)
        {
            var data = System.Text.Encoding.UTF8.GetBytes(text);
            return Send(data);
        }

        public void Dispose()
        {
            Close();
            _tcpClient?.Dispose();
        }
    }
}
