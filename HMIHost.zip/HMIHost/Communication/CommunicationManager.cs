using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using HMIHost.Utils;

namespace HMIHost.Communication
{
    /// <summary>
    /// 通信管理器 - 统一管理所有通信通道
    /// </summary>
    public class CommunicationManager : IDisposable
    {
        private readonly ConcurrentDictionary<string, ICommunicationChannel> _channels = new ConcurrentDictionary<string, ICommunicationChannel>();
        private readonly DataParserEngine _parserEngine;
        private readonly object _dataBufferLock = new object();
        private readonly Dictionary<string, List<byte>> _receiveBuffers = new Dictionary<string, List<byte>>();

        public event EventHandler<ChannelDataParsedEventArgs> DataParsed;
        public event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;
        public event EventHandler<CommunicationErrorEventArgs> ErrorOccurred;

        public CommunicationManager()
        {
            _parserEngine = new DataParserEngine();
            Logger.Information("[CommManager] 通信管理器已初始化");
        }

        /// <summary>注册通信通道</summary>
        public void RegisterChannel(ICommunicationChannel channel)
        {
            if (_channels.ContainsKey(channel.Name))
            {
                Logger.Warning($"[CommManager] 通道 {channel.Name} 已存在，将被替换");
                _channels[channel.Name].Dispose();
            }

            channel.DataReceived += OnChannelDataReceived;
            channel.ConnectionStateChanged += OnChannelConnectionStateChanged;
            channel.ErrorOccurred += OnChannelErrorOccurred;

            _channels[channel.Name] = channel;
            lock (_dataBufferLock)
            {
                _receiveBuffers[channel.Name] = new List<byte>();
            }

            Logger.Information($"[CommManager] 注册通道: {channel.Name}");
        }

        /// <summary>获取通道</summary>
        public ICommunicationChannel GetChannel(string name)
        {
            _channels.TryGetValue(name, out var channel);
            return channel;
        }

        /// <summary>获取所有通道</summary>
        public IEnumerable<ICommunicationChannel> GetAllChannels() => _channels.Values;

        /// <summary>打开指定通道</summary>
        public void OpenChannel(string name)
        {
            if (_channels.TryGetValue(name, out var channel))
            {
                Logger.Information($"[CommManager] 打开通道: {name}");
                channel.Open();
            }
        }

        /// <summary>关闭指定通道</summary>
        public void CloseChannel(string name)
        {
            if (_channels.TryGetValue(name, out var channel))
            {
                Logger.Information($"[CommManager] 关闭通道: {name}");
                channel.Close();
            }
        }

        /// <summary>打开所有通道</summary>
        public void OpenAll()
        {
            foreach (var ch in _channels.Values)
            {
                ch.Open();
            }
        }

        /// <summary>关闭所有通道</summary>
        public void CloseAll()
        {
            foreach (var ch in _channels.Values)
            {
                ch.Close();
            }
        }

        /// <summary>向指定通道发送数据</summary>
        public bool Send(string channelName, byte[] data)
        {
            if (_channels.TryGetValue(channelName, out var channel))
            {
                return channel.Send(data);
            }
            Logger.Warning($"[CommManager] 通道不存在: {channelName}");
            return false;
        }

        /// <summary>向指定通道发送文本</summary>
        public bool Send(string channelName, string text)
        {
            if (_channels.TryGetValue(channelName, out var channel))
            {
                return channel.Send(text);
            }
            Logger.Warning($"[CommManager] 通道不存在: {channelName}");
            return false;
        }

        /// <summary>向所有通道广播数据</summary>
        public void Broadcast(byte[] data)
        {
            foreach (var ch in _channels.Values.Where(c => c.IsConnected))
            {
                ch.Send(data);
            }
        }

        private void OnChannelDataReceived(object sender, DataReceivedEventArgs e)
        {
            // 粘包/拆包处理：将数据追加到缓冲区，尝试解析
            lock (_dataBufferLock)
            {
                if (!_receiveBuffers.ContainsKey(e.ChannelName))
                    _receiveBuffers[e.ChannelName] = new List<byte>();

                _receiveBuffers[e.ChannelName].AddRange(e.Data);

                var buffer = _receiveBuffers[e.ChannelName].ToArray();
                var results = _parserEngine.ParseData(e.ChannelName, buffer);

                if (results.Count > 0)
                {
                    // 计算已消费的字节数
                    int consumed = 0;
                    foreach (var r in results)
                    {
                        if (r.ContainsKey("RawFrame"))
                        {
                            var frame = (byte[])r["RawFrame"];
                            consumed += frame.Length;
                        }
                    }

                    // 移除已消费的数据
                    if (consumed > 0 && consumed <= _receiveBuffers[e.ChannelName].Count)
                    {
                        _receiveBuffers[e.ChannelName].RemoveRange(0, consumed);
                    }

                    // 触发解析完成事件
                    DataParsed?.Invoke(this, new ChannelDataParsedEventArgs(e.ChannelName, results));
                }
            }
        }

        private void OnChannelConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            ConnectionStateChanged?.Invoke(sender, e);
        }

        private void OnChannelErrorOccurred(object sender, CommunicationErrorEventArgs e)
        {
            Logger.Error($"[CommManager] 通道错误 [{e.ChannelName}]: {e.ErrorMessage}");
            ErrorOccurred?.Invoke(sender, e);
        }

        public void Dispose()
        {
            foreach (var ch in _channels.Values)
            {
                ch.Dispose();
            }
            _channels.Clear();
            Logger.Information("[CommManager] 通信管理器已释放");
        }
    }

    /// <summary>通道数据解析完成事件参数</summary>
    public class ChannelDataParsedEventArgs : EventArgs
    {
        public string ChannelName { get; }
        public List<Dictionary<string, object>> ParsedData { get; }
        public DateTime ParseTime { get; }

        public ChannelDataParsedEventArgs(string channelName, List<Dictionary<string, object>> parsedData)
        {
            ChannelName = channelName;
            ParsedData = parsedData;
            ParseTime = DateTime.Now;
        }
    }
}
