using System;

namespace HMIHost.Communication
{
    /// <summary>
    /// 通信通道接口 - 所有通信方式的统一抽象
    /// </summary>
    public interface ICommunicationChannel : IDisposable
    {
        /// <summary>通道名称（用于日志标识）</summary>
        string Name { get; }

        /// <summary>当前连接状态</summary>
        bool IsConnected { get; }

        /// <summary>连接状态变化事件</summary>
        event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;

        /// <summary>数据接收事件</summary>
        event EventHandler<DataReceivedEventArgs> DataReceived;

        /// <summary>错误信息事件</summary>
        event EventHandler<CommunicationErrorEventArgs> ErrorOccurred;

        /// <summary>打开连接</summary>
        void Open();

        /// <summary>关闭连接</summary>
        void Close();

        /// <summary>发送数据</summary>
        /// <param name="data">字节数据</param>
        /// <returns>发送是否成功</returns>
        bool Send(byte[] data);

        /// <summary>发送字符串（UTF-8 编码）</summary>
        bool Send(string text);
    }

    /// <summary>连接状态变化事件参数</summary>
    public class ConnectionStateChangedEventArgs : EventArgs
    {
        public bool IsConnected { get; }
        public string Message { get; }
        public ConnectionStateChangedEventArgs(bool isConnected, string message = "")
        {
            IsConnected = isConnected;
            Message = message;
        }
    }

    /// <summary>数据接收事件参数</summary>
    public class DataReceivedEventArgs : EventArgs
    {
        public byte[] Data { get; }
        public DateTime ReceiveTime { get; }
        public string ChannelName { get; }
        public DataReceivedEventArgs(byte[] data, string channelName)
        {
            Data = data;
            ReceiveTime = DateTime.Now;
            ChannelName = channelName;
        }
        /// <summary>以十六进制字符串获取</summary>
        public string HexString => BitConverter.ToString(Data).Replace("-", " ");
        /// <summary>以 UTF-8 字符串获取</summary>
        public string Text => System.Text.Encoding.UTF8.GetString(Data);
    }

    /// <summary>通信错误事件参数</summary>
    public class CommunicationErrorEventArgs : EventArgs
    {
        public string ChannelName { get; }
        public string ErrorMessage { get; }
        public Exception Exception { get; }
        public DateTime Time { get; }
        public CommunicationErrorEventArgs(string channelName, string errorMessage, Exception ex = null)
        {
            ChannelName = channelName;
            ErrorMessage = errorMessage;
            Exception = ex;
            Time = DateTime.Now;
        }
    }
}
