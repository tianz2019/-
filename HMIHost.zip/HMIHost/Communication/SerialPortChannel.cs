using System;
using System.IO.Ports;
using System.Text;
using HMIHost.Utils;

namespace HMIHost.Communication
{
    /// <summary>
    /// 串口通信通道
    /// </summary>
    public class SerialPortChannel : ICommunicationChannel
    {
        private readonly SerialPort _serialPort;
        private readonly object _lockObj = new object();

        public string Name { get; }

        public bool IsConnected => _serialPort?.IsOpen ?? false;

        public event EventHandler<ConnectionStateChangedEventArgs> ConnectionStateChanged;
        public event EventHandler<DataReceivedEventArgs> DataReceived;
        public event EventHandler<CommunicationErrorEventArgs> ErrorOccurred;

        public SerialPortChannel(string portName = "COM3", int baudRate = 9600,
            int dataBits = 8, StopBits stopBits = StopBits.One, Parity parity = Parity.None)
        {
            Name = $"Serial:{portName}";
            _serialPort = new SerialPort(portName, baudRate, parity, dataBits, stopBits)
            {
                ReadTimeout = 3000,
                WriteTimeout = 3000,
                DtrEnable = true,
                RtsEnable = true
            };
            _serialPort.DataReceived += OnSerialDataReceived;
        }

        public void Open()
        {
            try
            {
                lock (_lockObj)
                {
                    if (!_serialPort.IsOpen)
                    {
                        _serialPort.Open();
                        Logger.Information($"[{Name}] 串口已打开");
                        ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(true, "串口已连接"));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 打开串口失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "打开串口失败", ex));
                ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, ex.Message));
            }
        }

        public void Close()
        {
            try
            {
                lock (_lockObj)
                {
                    if (_serialPort.IsOpen)
                    {
                        _serialPort.Close();
                        Logger.Information($"[{Name}] 串口已关闭");
                        ConnectionStateChanged?.Invoke(this, new ConnectionStateChangedEventArgs(false, "串口已断开"));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 关闭串口失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "关闭串口失败", ex));
            }
        }

        public bool Send(byte[] data)
        {
            try
            {
                lock (_lockObj)
                {
                    if (!_serialPort.IsOpen)
                    {
                        Logger.Warning($"[{Name}] 串口未打开，无法发送数据");
                        return false;
                    }
                    _serialPort.Write(data, 0, data.Length);
                    Logger.Debug($"[{Name}] 发送[{data.Length}字节]: {BitConverter.ToString(data)}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 发送失败: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "发送失败", ex));
                return false;
            }
        }

        public bool Send(string text)
        {
            var data = Encoding.UTF8.GetBytes(text);
            return Send(data);
        }

        private void OnSerialDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (_serialPort.BytesToRead <= 0) return;

                var buffer = new byte[_serialPort.BytesToRead];
                var readCount = _serialPort.Read(buffer, 0, buffer.Length);

                if (readCount <= 0) return;

                var data = new byte[readCount];
                Array.Copy(buffer, data, readCount);

                Logger.Debug($"[{Name}] 接收[{readCount}字节]: {BitConverter.ToString(data)}");
                DataReceived?.Invoke(this, new DataReceivedEventArgs(data, Name));
            }
            catch (Exception ex)
            {
                Logger.Error($"[{Name}] 接收数据出错: {ex.Message}");
                ErrorOccurred?.Invoke(this, new CommunicationErrorEventArgs(Name, "接收数据出错", ex));
            }
        }

        public void Dispose()
        {
            Close();
            _serialPort?.Dispose();
        }
    }
}
