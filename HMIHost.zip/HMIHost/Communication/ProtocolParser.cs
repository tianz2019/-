using System;
using System.Collections.Generic;
using System.Text;

namespace HMIHost.Communication
{
    /// <summary>
    /// 协议帧解析器接口
    /// </summary>
    public interface IProtocolParser
    {
        /// <summary>协议名称</summary>
        string ProtocolName { get; }

        /// <summary>尝试从字节缓冲区中提取一帧完整数据</summary>
        /// <param name="buffer">输入缓冲区</param>
        /// <param name="offset">起始偏移</param>
        /// <param name="length">有效数据长度</param>
        /// <param name="frame">输出：提取到的完整帧（若成功）</param>
        /// <param name="consumed">输出：本次消耗的字节数</param>
        /// <returns>是否成功提取一帧</returns>
        bool TryParseFrame(byte[] buffer, int offset, int length, out byte[] frame, out int consumed);

        /// <summary>解析帧为业务对象</summary>
        /// <param name="frame">完整帧数据</param>
        /// <returns>解析后的键值对集合</returns>
        Dictionary<string, object> ParseFrame(byte[] frame);
    }

    /// <summary>
    /// 通用帧格式：
    /// [Head(2)][Length(2)][Command(1)][Data(N)][Checksum(1)][Tail(2)]
    /// Head: 0xAA 0x55
    /// Tail: 0x0D 0x0A
    /// Checksum: 从 Length 到 Data 末尾所有字节之和的低8位
    /// </summary>
    public class CustomFrameParser : IProtocolParser
    {
        public string ProtocolName => "CustomFrame";

        private const byte HEAD1 = 0xAA;
        private const byte HEAD2 = 0x55;
        private const byte TAIL1 = 0x0D;
        private const byte TAIL2 = 0x0A;

        public bool TryParseFrame(byte[] buffer, int offset, int length, out byte[] frame, out int consumed)
        {
            frame = null;
            consumed = 0;

            if (length < 6) return false; // 最小帧长度

            // 查找帧头
            int headIndex = -1;
            for (int i = offset; i <= offset + length - 2; i++)
            {
                if (buffer[i] == HEAD1 && buffer[i + 1] == HEAD2)
                {
                    headIndex = i;
                    break;
                }
            }

            if (headIndex < 0) { consumed = length; return false; }

            // 从帧头开始，至少需要 4 字节才能读到 Length
            if (offset + length - headIndex < 4) { consumed = headIndex - offset; return false; }

            // 读取 Length（小端，含 Command + Data）
            int len = buffer[headIndex + 2] | (buffer[headIndex + 3] << 8);

            int totalFrameLen = 2 + 2 + len + 1 + 2; // Head + Length + Payload + Checksum + Tail

            if (offset + length - headIndex < totalFrameLen)
            {
                // 数据不够，等待更多数据
                consumed = headIndex - offset;
                return false;
            }

            // 提取完整帧
            frame = new byte[totalFrameLen];
            Array.Copy(buffer, headIndex, frame, 0, totalFrameLen);

            // 验证帧尾
            if (frame[totalFrameLen - 2] != TAIL1 || frame[totalFrameLen - 1] != TAIL2)
            {
                consumed = headIndex + 1 - offset; // 跳过第一个字节，重新找帧头
                frame = null;
                return false;
            }

            // 验证校验和
            byte checksum = 0;
            for (int i = 2; i < totalFrameLen - 3; i++)
            {
                checksum = (byte)(checksum + frame[i]);
            }
            if (checksum != frame[totalFrameLen - 3])
            {
                Logger?.Warning($"[Protocol] 校验和错误: 期望 0x{frame[totalFrameLen - 3]:X2}, 实际 0x{checksum:X2}");
                consumed = headIndex + 1 - offset;
                frame = null;
                return false;
            }

            consumed = headIndex + totalFrameLen - offset;
            return true;
        }

        public Dictionary<string, object> ParseFrame(byte[] frame)
        {
            var result = new Dictionary<string, object>();

            // Length 在偏移 2,3
            int len = frame[2] | (frame[3] << 8);

            // Command 在偏移 4
            byte command = frame[4];
            result["Command"] = command;
            result["CommandHex"] = $"0x{command:X2}";

            // Data 从偏移 5 开始，长度为 len - 1（减去 Command 占的1字节）
            int dataLen = len - 1;
            if (dataLen > 0)
            {
                var data = new byte[dataLen];
                Array.Copy(frame, 5, data, 0, dataLen);
                result["Data"] = data;
                result["DataHex"] = BitConverter.ToString(data).Replace("-", " ");
            }

            result["RawFrame"] = frame;
            result["FrameHex"] = BitConverter.ToString(frame).Replace("-", " ");

            return result;
        }

        // 避免对 ILogger 的直接依赖
        private static Serilog? _logger;
        private static Serilog Logger => _logger ??= new Serilog();
        private class Serilog { public void Warning(string msg) => System.Diagnostics.Debug.WriteLine(msg); }
    }

    /// <summary>
    /// 数据解析引擎 - 管理所有协议解析器
    /// </summary>
    public class DataParserEngine
    {
        private readonly Dictionary<string, IProtocolParser> _parsers = new Dictionary<string, IProtocolParser>();
        private IProtocolParser _defaultParser;

        public DataParserEngine()
        {
            // 注册默认解析器
            RegisterParser(new CustomFrameParser());
            _defaultParser = _parsers[new CustomFrameParser().ProtocolName];
        }

        /// <summary>注册协议解析器</summary>
        public void RegisterParser(IProtocolParser parser)
        {
            _parsers[parser.ProtocolName] = parser;
            Console.WriteLine($"[DataParser] 注册协议解析器: {parser.ProtocolName}");
        }

        /// <summary>设置默认解析器</summary>
        public void SetDefaultParser(string protocolName)
        {
            if (_parsers.ContainsKey(protocolName))
            {
                _defaultParser = _parsers[protocolName];
                Console.WriteLine($"[DataParser] 设置默认解析器: {protocolName}");
            }
        }

        /// <summary>解析接收到的数据（支持粘包/拆包）</summary>
        public List<Dictionary<string, object>> ParseData(string channelName, byte[] data)
        {
            var results = new List<Dictionary<string, object>>();
            if (_defaultParser == null) return results;

            // 使用静态缓冲区模拟接收缓冲
            // 实际项目中建议使用 Channel<T> 或 ConcurrentQueue
            var buffer = data; // 简化处理，每次独立解析

            int offset = 0;
            int length = buffer.Length;

            while (offset < buffer.Length)
            {
                if (_defaultParser.TryParseFrame(buffer, offset, length, out var frame, out var consumed))
                {
                    if (frame != null)
                    {
                        var parsed = _defaultParser.ParseFrame(frame);
                        parsed["ChannelName"] = channelName;
                        parsed["Timestamp"] = DateTime.Now;
                        results.Add(parsed);
                    }
                    offset += consumed;
                    length = buffer.Length - offset;
                }
                else
                {
                    break;
                }
            }

            return results;
        }

        /// <summary>构建自定义帧</summary>
        public static byte[] BuildFrame(byte command, byte[] data)
        {
            int payloadLen = 1 + (data?.Length ?? 0); // Command + Data
            int totalLen = 2 + 2 + payloadLen + 1 + 2; // Head + Length + Payload + Checksum + Tail

            var frame = new byte[totalLen];
            frame[0] = HEAD1;
            frame[1] = HEAD2;
            frame[2] = (byte)(payloadLen & 0xFF);
            frame[3] = (byte)((payloadLen >> 8) & 0xFF);
            frame[4] = command;

            if (data != null && data.Length > 0)
            {
                Array.Copy(data, 0, frame, 5, data.Length);
            }

            // 计算校验和
            byte checksum = 0;
            for (int i = 2; i < totalLen - 3; i++)
            {
                checksum = (byte)(checksum + frame[i]);
            }
            frame[totalLen - 3] = checksum;
            frame[totalLen - 2] = TAIL1;
            frame[totalLen - 1] = TAIL2;

            return frame;
        }

        // 帧常量暴露给 BuildFrame
        private const byte HEAD1 = 0xAA;
        private const byte HEAD2 = 0x55;
        private const byte TAIL1 = 0x0D;
        private const byte TAIL2 = 0x0A;
    }
}
