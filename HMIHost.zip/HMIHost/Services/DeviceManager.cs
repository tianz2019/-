using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using HMIHost.Communication;
using HMIHost.Models;
using HMIHost.Utils;

namespace HMIHost.Services
{
    /// <summary>
    /// 设备管理器 - 管理连接设备及其数据
    /// </summary>
    public class DeviceManager
    {
        private readonly CommunicationManager _commManager;
        private readonly ConcurrentDictionary<string, DeviceInfo> _devices = new ConcurrentDictionary<string, DeviceInfo>();
        private readonly Timer _pollingTimer;
        private volatile bool _isPolling = false;

        public event EventHandler<DeviceDataUpdatedEventArgs> DeviceDataUpdated;
        public event EventHandler<DeviceListChangedEventArgs> DeviceListChanged;

        public CommunicationManager CommunicationManager => _commManager;

        public DeviceManager(CommunicationManager commManager)
        {
            _commManager = commManager;

            // 注册数据解析事件
            _commManager.DataParsed += OnDataParsed;

            // 轮询定时器（默认 1 秒）
            _pollingTimer = new Timer(PollingCallback, null, Timeout.Infinite, Timeout.Infinite);
        }

        /// <summary>注册设备</summary>
        public void RegisterDevice(DeviceInfo device)
        {
            _devices[device.Id] = device;
            Logger.Information($"[DeviceMgr] 注册设备: {device.Name} (ID={device.Id}, Type={device.Type})");

            // 为设备创建对应的通信通道
            CreateChannelForDevice(device);

            DeviceListChanged?.Invoke(this, new DeviceListChangedEventArgs(_devices.Values.ToList()));
        }

        /// <summary>移除设备</summary>
        public void UnregisterDevice(string deviceId)
        {
            if (_devices.TryRemove(deviceId, out var device))
            {
                // 关闭对应通道
                _commManager.CloseChannel($"{device.Type}:{device.ConnectionString}");
                Logger.Information($"[DeviceMgr] 移除设备: {device.Name}");
                DeviceListChanged?.Invoke(this, new DeviceListChangedEventArgs(_devices.Values.ToList()));
            }
        }

        /// <summary>获取所有设备</summary>
        public IEnumerable<DeviceInfo> GetAllDevices() => _devices.Values;

        /// <summary>获取设备</summary>
        public DeviceInfo GetDevice(string deviceId)
        {
            _devices.TryGetValue(deviceId, out var device);
            return device;
        }

        /// <summary>启动轮询</summary>
        public void StartPolling(int intervalMs = 1000)
        {
            if (_isPolling) return;
            _isPolling = true;
            _pollingTimer.Change(0, intervalMs);
            Logger.Information($"[DeviceMgr] 启动数据轮询，间隔 {intervalMs}ms");
        }

        /// <summary>停止轮询</summary>
        public void StopPolling()
        {
            _isPolling = false;
            _pollingTimer.Change(Timeout.Infinite, Timeout.Infinite);
            Logger.Information("[DeviceMgr] 停止数据轮询");
        }

        /// <summary>打开所有设备连接</summary>
        public void ConnectAll()
        {
            foreach (var device in _devices.Values)
            {
                if (device.AutoConnect)
                {
                    ConnectDevice(device.Id);
                }
            }
        }

        /// <summary>连接指定设备</summary>
        public void ConnectDevice(string deviceId)
        {
            if (!_devices.TryGetValue(deviceId, out var device)) return;

            var channelName = $"{device.Type}:{device.ConnectionString}";
            _commManager.OpenChannel(channelName);
            device.IsOnline = true;
        }

        /// <summary>断开指定设备</summary>
        public void DisconnectDevice(string deviceId)
        {
            if (!_devices.TryGetValue(deviceId, out var device)) return;

            var channelName = $"{device.Type}:{device.ConnectionString}";
            _commManager.CloseChannel(channelName);
            device.IsOnline = false;
        }

        /// <summary>断开所有设备</summary>
        public void DisconnectAll()
        {
            _commManager.CloseAll();
            foreach (var device in _devices.Values)
            {
                device.IsOnline = false;
            }
        }

        private void CreateChannelForDevice(DeviceInfo device)
        {
            // 这里根据设备类型创建对应的通信通道
            // 实际项目中应从配置文件读取详细参数
            ICommunicationChannel channel = null;

            switch (device.Type)
            {
                case ChannelType.SerialPort:
                    channel = new SerialPortChannel(device.ConnectionString);
                    break;
                case ChannelType.ModbusTcp:
                    var parts = device.ConnectionString.Split(':');
                    var ip = parts[0];
                    var port = parts.Length > 1 ? int.Parse(parts[1]) : 502;
                    channel = new ModbusTcpChannel(ip, port, device.SlaveId);
                    break;
                case ChannelType.TcpSocket:
                    var tcpParts = device.ConnectionString.Split(':');
                    var tcpIp = tcpParts[0];
                    var tcpPort = tcpParts.Length > 1 ? int.Parse(tcpParts[1]) : 9000;
                    channel = new TcpSocketChannel(tcpIp, tcpPort);
                    break;
                case ChannelType.UdpSocket:
                    var udpParts = device.ConnectionString.Split(':');
                    var localPort = int.Parse(udpParts[0]);
                    var remoteIp = udpParts.Length > 1 ? udpParts[1] : "127.0.0.1";
                    var remotePort = udpParts.Length > 2 ? int.Parse(udpParts[2]) : localPort;
                    channel = new UdpSocketChannel(localPort, remoteIp, remotePort);
                    break;
            }

            if (channel != null)
            {
                _commManager.RegisterChannel(channel);
                device.ChannelName = channel.Name;
            }
        }

        private void OnDataParsed(object sender, ChannelDataParsedEventArgs e)
        {
            // 查找对应设备并更新数据
            foreach (var device in _devices.Values)
            {
                if (device.ChannelName == e.ChannelName)
                {
                    device.LastDataTime = DateTime.Now;

                    foreach (var data in e.ParsedData)
                    {
                        device.UpdateData(data);
                    }

                    DeviceDataUpdated?.Invoke(this, new DeviceDataUpdatedEventArgs(device, e.ParsedData));
                }
            }
        }

        private void PollingCallback(object state)
        {
            if (!_isPolling) return;

            try
            {
                foreach (var device in _devices.Values.Where(d => d.IsOnline && d.PollEnabled))
                {
                    // 这里可以实现周期性的数据请求逻辑
                    // 例如：定时读取 Modbus 寄存器、发送心跳包等
                    if (device.Type == ChannelType.ModbusTcp && _commManager.GetChannel(device.ChannelName) is ModbusTcpChannel modbusChannel)
                    {
                        // 示例：读取保持寄存器（实际项目中根据设备点表配置）
                        // var values = modbusChannel.ReadHoldingRegisters(0, 10);
                        // if (values != null) device.UpdateRegisters(values);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"[DeviceMgr] 轮询异常: {ex.Message}");
            }
        }

        public void Dispose()
        {
            StopPolling();
            _pollingTimer?.Dispose();
            _commManager?.Dispose();
        }
    }

    /// <summary>
    /// 设备信息
    /// </summary>
    public class DeviceInfo
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
        public string Name { get; set; }
        public ChannelType Type { get; set; }
        public string ConnectionString { get; set; }
        public byte SlaveId { get; set; } = 1;
        public bool AutoConnect { get; set; } = true;
        public bool PollEnabled { get; set; } = true;
        public bool IsOnline { get; set; }
        public string ChannelName { get; set; }
        public DateTime LastDataTime { get; set; }
        public DateTime RegisterTime { get; set; } = DateTime.Now;

        /// <summary>设备实时数据字典</summary>
        private readonly Dictionary<string, object> _data = new Dictionary<string, object>();
        private readonly object _dataLock = new object();

        public IReadOnlyDictionary<string, object> Data
        {
            get { lock (_dataLock) return new Dictionary<string, object>(_data); }
        }

        public void UpdateData(string key, object value)
        {
            lock (_dataLock) _data[key] = value;
        }

        public void UpdateData(Dictionary<string, object> data)
        {
            lock (_dataLock)
            {
                foreach (var kvp in data)
                {
                    if (kvp.Key != "ChannelName" && kvp.Key != "Timestamp")
                        _data[kvp.Key] = kvp.Value;
                }
            }
        }

        public T GetData<T>(string key, T defaultValue = default)
        {
            lock (_dataLock)
            {
                if (_data.TryGetValue(key, out var value) && value is T typed)
                    return typed;
                return defaultValue;
            }
        }
    }

    /// <summary>设备数据更新事件参数</summary>
    public class DeviceDataUpdatedEventArgs : EventArgs
    {
        public DeviceInfo Device { get; }
        public List<Dictionary<string, object>> Data { get; }
        public DeviceDataUpdatedEventArgs(DeviceInfo device, List<Dictionary<string, object>> data)
        {
            Device = device;
            Data = data;
        }
    }

    /// <summary>设备列表变化事件参数</summary>
    public class DeviceListChangedEventArgs : EventArgs
    {
        public List<DeviceInfo> Devices { get; }
        public DeviceListChangedEventArgs(List<DeviceInfo> devices) { Devices = devices; }
    }
}
