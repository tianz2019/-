using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace HMIHost.Models
{
    /// <summary>
    /// 串口配置
    /// </summary>
    public class SerialPortConfig
    {
        public string PortName { get; set; } = "COM3";
        public int BaudRate { get; set; } = 9600;
        public int DataBits { get; set; } = 8;
        public StopBitsConfig StopBits { get; set; } = StopBitsConfig.One;
        public ParityConfig Parity { get; set; } = ParityConfig.None;
        public int ReadTimeout { get; set; } = 3000;
        public int WriteTimeout { get; set; } = 3000;
    }

    /// <summary>
    /// Modbus TCP 配置
    /// </summary>
    public class ModbusTcpConfig
    {
        public string IpAddress { get; set; } = "127.0.0.1";
        public int Port { get; set; } = 502;
        public byte SlaveId { get; set; } = 1;
        public int Timeout { get; set; } = 5000;
        public int RetryCount { get; set; } = 3;
    }

    /// <summary>
    /// TCP Socket 配置
    /// </summary>
    public class TcpSocketConfig
    {
        public string IpAddress { get; set; } = "127.0.0.1";
        public int Port { get; set; } = 9000;
        public int ReceiveBufferSize { get; set; } = 4096;
        public int ReconnectInterval { get; set; } = 5000;
    }

    /// <summary>
    /// UDP Socket 配置
    /// </summary>
    public class UdpSocketConfig
    {
        public int LocalPort { get; set; } = 9001;
        public string RemoteIp { get; set; } = "127.0.0.1";
        public int RemotePort { get; set; } = 9001;
        public int ReceiveBufferSize { get; set; } = 4096;
    }

    /// <summary>
    /// 应用全局配置
    /// </summary>
    public class AppConfig
    {
        public SerialPortConfig SerialPort { get; set; } = new SerialPortConfig();
        public ModbusTcpConfig ModbusTcp { get; set; } = new ModbusTcpConfig();
        public TcpSocketConfig TcpSocket { get; set; } = new TcpSocketConfig();
        public UdpSocketConfig UdpSocket { get; set; } = new UdpSocketConfig();
        public LoggingConfig Logging { get; set; } = new LoggingConfig();
    }

    public class LoggingConfig
    {
        public string LogLevel { get; set; } = "Information";
        public string LogFilePath { get; set; } = "Logs/hmi-{Date}.log";
        public int RetainedFileCountLimit { get; set; } = 30;
    }

    public enum StopBitsConfig { One, Two, OnePointFive }
    public enum ParityConfig { None, Odd, Even, Mark, Space }

    /// <summary>
    /// 通信通道类型枚举
    /// </summary>
    public enum ChannelType { SerialPort, ModbusTcp, TcpSocket, UdpSocket }

    /// <summary>
    /// 通道状态模型（用于 UI 绑定）
    /// </summary>
    public class ChannelStatus
    {
        public string Name { get; set; }
        public ChannelType Type { get; set; }
        public bool IsConnected { get; set; }
        public DateTime LastActivityTime { get; set; }
        public long ReceivedBytes { get; set; }
        public long SentBytes { get; set; }
        public string StatusText => IsConnected ? "● 已连接" : "○ 未连接";
    }

    /// <summary>
    /// 日志条目模型（用于 UI 显示）
    /// </summary>
    public class LogEntry
    {
        public DateTime Time { get; set; }
        public string Level { get; set; }
        public string Message { get; set; }
        public string Source { get; set; }

        public LogEntry() { }

        public LogEntry(string level, string message, string source = "")
        {
            Time = DateTime.Now;
            Level = level;
            Message = message;
            Source = source;
        }
    }
}
