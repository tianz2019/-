using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using HMIHost.Communication;
using HMIHost.Models;
using HMIHost.Services;
using HMIHost.Utils;

namespace HMIHost.ViewModels
{
    /// <summary>
    /// 主窗口 ViewModel
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        private readonly DeviceManager _deviceManager;
        private readonly Dispatcher _dispatcher;
        private string _title = "HMI 上位机应用框架 v1.0";
        private string _statusBarText = "就绪";
        private bool _isConnected;
        private int _selectedTabIndex;
        private string _inputText = "";
        private string _selectedChannelName = "";
        private int _receivedCount;
        private int _sentCount;
        private DateTime _startTime = DateTime.Now;

        public string Title
        {
            get => _title;
            set => SetProperty(ref _title, value);
        }

        public string StatusBarText
        {
            get => _statusBarText;
            set => SetProperty(ref _statusBarText, value);
        }

        public bool IsConnected
        {
            get => _isConnected;
            set
            {
                SetProperty(ref _isConnected, value);
                OnPropertyChanged(nameof(ConnectionStatusText));
            }
        }

        public string ConnectionStatusText => IsConnected ? "● 已连接" : "○ 未连接";

        public int SelectedTabIndex
        {
            get => _selectedTabIndex;
            set => SetProperty(ref _selectedTabIndex, value);
        }

        public string InputText
        {
            get => _inputText;
            set => SetProperty(ref _inputText, value);
        }

        public string SelectedChannelName
        {
            get => _selectedChannelName;
            set => SetProperty(ref _selectedChannelName, value);
        }

        public int ReceivedCount
        {
            get => _receivedCount;
            set => SetProperty(ref _receivedCount, value);
        }

        public int SentCount
        {
            get => _sentCount;
            set => SetProperty(ref _sentCount, value);
        }

        public TimeSpan RunningTime => DateTime.Now - _startTime;

        /// <summary>通道状态列表（UI 绑定）</summary>
        public ObservableCollection<ChannelStatus> Channels { get; } = new ObservableCollection<ChannelStatus>();

        /// <summary>日志条目列表（UI 绑定）</summary>
        public ObservableCollection<LogEntry> LogEntries { get; } = new ObservableCollection<LogEntry>();

        /// <summary>可用通道名称列表</summary>
        public ObservableCollection<string> ChannelNames { get; } = new ObservableCollection<string>();

        // 命令
        public RelayCommand ConnectCommand { get; }
        public RelayCommand DisconnectCommand { get; }
        public RelayCommand SendCommand { get; }
        public RelayCommand ClearLogCommand { get; }
        public RelayCommand AddDeviceCommand { get; }
        public RelayCommand StartPollingCommand { get; }
        public RelayCommand StopPollingCommand { get; }

        public MainViewModel()
        {
            _dispatcher = Dispatcher.CurrentDispatcher;
            _deviceManager = new DeviceManager(new CommunicationManager());

            // 初始化默认通道
            InitializeDefaultChannels();

            // 订阅事件
            _deviceManager.CommunicationManager.ConnectionStateChanged += OnConnectionStateChanged;
            _deviceManager.CommunicationManager.DataParsed += OnDataParsed;
            _deviceManager.CommunicationManager.ErrorOccurred += OnCommError;
            _deviceManager.DeviceDataUpdated += OnDeviceDataUpdated;
            _deviceManager.DeviceListChanged += OnDeviceListChanged;

            // 启动运行时间计时器
            var timer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            timer.Tick += (s, e) => OnPropertyChanged(nameof(RunningTime));
            timer.Start();

            // 初始化命令
            ConnectCommand = new RelayCommand(ExecuteConnect);
            DisconnectCommand = new RelayCommand(ExecuteDisconnect);
            SendCommand = new RelayCommand(ExecuteSend, CanExecuteSend);
            ClearLogCommand = new RelayCommand(ExecuteClearLog);
            AddDeviceCommand = new RelayCommand(ExecuteAddDevice);
            StartPollingCommand = new RelayCommand(ExecuteStartPolling);
            StopPollingCommand = new RelayCommand(ExecuteStopPolling);

            // 初始日志
            AddLogEntry("Information", "应用程序已启动");
            AddLogEntry("Information", $"已注册 {Channels.Count} 个通信通道");

            // 默认选择第一个通道
            if (ChannelNames.Count > 0)
                SelectedChannelName = ChannelNames[0];
        }

        private void InitializeDefaultChannels()
        {
            var commMgr = _deviceManager.CommunicationManager;

            // 注册串口通道
            commMgr.RegisterChannel(new SerialPortChannel("COM3", 9600));
            Channels.Add(new ChannelStatus { Name = "Serial:COM3", Type = ChannelType.SerialPort });
            ChannelNames.Add("Serial:COM3");

            // 注册 Modbus TCP 通道
            commMgr.RegisterChannel(new ModbusTcpChannel("127.0.0.1", 502, 1));
            Channels.Add(new ChannelStatus { Name = "ModbusTCP:127.0.0.1:502", Type = ChannelType.ModbusTcp });
            ChannelNames.Add("ModbusTCP:127.0.0.1:502");

            // 注册 TCP Socket 通道
            commMgr.RegisterChannel(new TcpSocketChannel("127.0.0.1", 9000));
            Channels.Add(new ChannelStatus { Name = "TCP:127.0.0.1:9000", Type = ChannelType.TcpSocket });
            ChannelNames.Add("TCP:127.0.0.1:9000");

            // 注册 UDP Socket 通道
            commMgr.RegisterChannel(new UdpSocketChannel(9001, "127.0.0.1", 9001));
            Channels.Add(new ChannelStatus { Name = "UDP:127.0.0.1:9001", Type = ChannelType.UdpSocket });
            ChannelNames.Add("UDP:127.0.0.1:9001");
        }

        private void ExecuteConnect(object parameter)
        {
            try
            {
                if (parameter is string channelName && !string.IsNullOrEmpty(channelName))
                {
                    _deviceManager.CommunicationManager.OpenChannel(channelName);
                    AddLogEntry("Information", $"正在连接通道: {channelName}");
                }
                else
                {
                    // 连接所有
                    _deviceManager.ConnectAll();
                    AddLogEntry("Information", "正在连接所有通道...");
                }
                StatusBarText = "正在连接...";
            }
            catch (Exception ex)
            {
                AddLogEntry("Error", $"连接失败: {ex.Message}");
                Logger.Error(ex, "连接失败");
            }
        }

        private void ExecuteDisconnect(object parameter)
        {
            try
            {
                if (parameter is string channelName && !string.IsNullOrEmpty(channelName))
                {
                    _deviceManager.CommunicationManager.CloseChannel(channelName);
                    AddLogEntry("Information", $"已断开通道: {channelName}");
                }
                else
                {
                    _deviceManager.DisconnectAll();
                    AddLogEntry("Information", "已断开所有通道");
                }
                StatusBarText = "已断开";
            }
            catch (Exception ex)
            {
                AddLogEntry("Error", $"断开失败: {ex.Message}");
                Logger.Error(ex, "断开失败");
            }
        }

        private bool CanExecuteSend(object parameter) => !string.IsNullOrEmpty(SelectedChannelName) && IsConnected;

        private void ExecuteSend(object parameter)
        {
            if (string.IsNullOrEmpty(InputText)) return;

            try
            {
                // 尝试按 Hex 发送
                byte[] data;
                if (InputText.StartsWith("0x") || InputText.Contains(" "))
                {
                    var hexStr = InputText.Replace("0x", "").Replace(" ", "");
                    data = HexStringToBytes(hexStr);
                }
                else
                {
                    data = System.Text.Encoding.UTF8.GetBytes(InputText);
                }

                bool result = _deviceManager.CommunicationManager.Send(SelectedChannelName, data);
                if (result)
                {
                    SentCount++;
                    AddLogEntry("Debug", $"[{SelectedChannelName}] 发送: {InputText}");
                }
                else
                {
                    AddLogEntry("Warning", $"[{SelectedChannelName}] 发送失败，通道未连接");
                }
            }
            catch (Exception ex)
            {
                AddLogEntry("Error", $"发送异常: {ex.Message}");
            }
        }

        private void ExecuteClearLog(object parameter)
        {
            _dispatcher.Invoke(() => LogEntries.Clear());
        }

        private void ExecuteAddDevice(object parameter)
        {
            // 弹出设备添加窗口（简化版直接创建示例设备）
            var device = new DeviceInfo
            {
                Name = $"Device_{_deviceManager.GetAllDevices().Count() + 1}",
                Type = ChannelType.ModbusTcp,
                ConnectionString = "127.0.0.1:502",
                SlaveId = 1
            };
            _deviceManager.RegisterDevice(device);
            AddLogEntry("Information", $"添加设备: {device.Name} @ {device.ConnectionString}");
        }

        private void ExecuteStartPolling(object parameter)
        {
            _deviceManager.StartPolling(1000);
            AddLogEntry("Information", "启动数据轮询");
        }

        private void ExecuteStopPolling(object parameter)
        {
            _deviceManager.StopPolling();
            AddLogEntry("Information", "停止数据轮询");
        }

        private void OnConnectionStateChanged(object sender, ConnectionStateChangedEventArgs e)
        {
            _dispatcher.Invoke(() =>
            {
                var channel = Channels.FirstOrDefault(c => c.Name == ((ICommunicationChannel)sender)?.Name);
                if (channel != null)
                {
                    channel.IsConnected = e.IsConnected;
                    channel.LastActivityTime = DateTime.Now;
                }

                IsConnected = e.IsConnected;
                StatusBarText = e.IsConnected ? "已连接" : "未连接";

                AddLogEntry(e.IsConnected ? "Information" : "Warning",
                    $"[{((ICommunicationChannel)sender)?.Name}] {(e.IsConnected ? "已连接" : "已断开")} {e.Message}");
            });
        }

        private void OnDataParsed(object sender, ChannelDataParsedEventArgs e)
        {
            _dispatcher.Invoke(() =>
            {
                ReceivedCount += e.ParsedData.Count;

                foreach (var data in e.ParsedData)
                {
                    var frameHex = data.ContainsKey("FrameHex") ? data["FrameHex"].ToString() : "";
                    var command = data.ContainsKey("CommandHex") ? data["CommandHex"].ToString() : "";

                    AddLogEntry("Debug", $"[{e.ChannelName}] 收到帧 Command={command} Data={frameHex}");

                    // 更新通道状态
                    var channel = Channels.FirstOrDefault(c => c.Name == e.ChannelName);
                    if (channel != null)
                    {
                        channel.ReceivedBytes += (data.ContainsKey("RawFrame") && data["RawFrame"] is byte[] raw) ? raw.Length : 0;
                        channel.LastActivityTime = DateTime.Now;
                    }
                }
            });
        }

        private void OnCommError(object sender, CommunicationErrorEventArgs e)
        {
            _dispatcher.Invoke(() =>
            {
                AddLogEntry("Error", $"[{e.ChannelName}] 通信错误: {e.ErrorMessage}");
            });
        }

        private void OnDeviceDataUpdated(object sender, DeviceDataUpdatedEventArgs e)
        {
            _dispatcher.Invoke(() =>
            {
                AddLogEntry("Debug", $"[{e.Device.Name}] 数据已更新，共 {e.Data.Count} 条");
            });
        }

        private void OnDeviceListChanged(object sender, DeviceListChangedEventArgs e)
        {
            _dispatcher.Invoke(() =>
            {
                AddLogEntry("Information", $"设备列表已更新，当前共 {e.Devices.Count} 个设备");
            });
        }

        private void AddLogEntry(string level, string message)
        {
            _dispatcher.Invoke(() =>
            {
                LogEntries.Add(new LogEntry(level, message));

                // 限制日志条目数量（最多保留 1000 条）
                while (LogEntries.Count > 1000)
                    LogEntries.RemoveAt(0);
            });

            // 同时写入文件日志
            switch (level)
            {
                case "Debug": Logger.Debug(message); break;
                case "Information": Logger.Information(message); break;
                case "Warning": Logger.Warning(message); break;
                case "Error": Logger.Error(message); break;
            }
        }

        private byte[] HexStringToBytes(string hex)
        {
            if (hex.Length % 2 != 0)
                throw new ArgumentException("十六进制字符串长度必须为偶数");

            var bytes = new byte[hex.Length / 2];
            for (int i = 0; i < bytes.Length; i++)
            {
                bytes[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
            }
            return bytes;
        }
    }
}
